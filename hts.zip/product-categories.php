<!--category-->
<div class="sidebar-widget category wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                        	<div class="sec-title-seven"><h2>Product Categories</h2></div>
                            
                            <ul>
                            	<li><a href="pharma-machineries.php"><span class="fa fa-plus-square-o"></span> Pharma Machineries</a></li>
                                <li><a href="food-industry-machineries.php"><span class="fa fa-plus-square-o"></span> Food Industry Machineries</a></li>
                                <li><a href="metal-detectors.php"><span class="fa fa-plus-square-o"></span> Metal Detectors</a></li>
                                <li><a href="conveyors.php"><span class="fa fa-plus-square-o"></span> All Types of Conveyor</a></li>
                            </ul>
                            
                        </div>