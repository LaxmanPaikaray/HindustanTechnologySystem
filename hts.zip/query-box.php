<!--Call TO Action-->
<div class="sidebar-widget call-to-action-four wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms" style="background-image:url(images/resource/quote-widget.jpg);">
                        	<div class="title">Any Questions related Industrial Solution? Call us</div>
                            
                            <div class="number"><span class="fa fa-phone"></span> +91-7410-176680</div>
                            <a class="theme-btn btn-style-one"  data-toggle="modal" data-target="#enquiryModal">GET QUOTES</a>
                        </div>