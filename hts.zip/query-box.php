<!--Call TO Action-->
<div class="sidebar-widget call-to-action-four wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms" style="background-image:url(images/resource/quote-widget.jpg);">
                        	<div class="title">Any Questions related Industrial Solution? Call us</div>
                            
                            <div class="number"><span class="fa fa-phone"></span> +001-345-6789-00</div>
                            <a class="theme-btn btn-style-one" href="contact.html">GET QUOTES</a>
                        </div>