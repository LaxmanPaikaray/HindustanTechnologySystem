<!--Main Footer-->
<footer class="main-footer">
    	
        <!--Footer Upper-->        
        <div class="footer-upper">
            <div class="auto-container">
                <div class="row clearfix">
                	
                    <!--Two 4th column-->
                    <div class="col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">
                            <div class="col-lg-7 col-sm-6 col-xs-12 column">
                                <div class="footer-widget logo-widget">
                                    <div class="logo"><a href="index.html"><img src="images/finalogo(1).png" class="img-responsive" alt=""></a></div>
                                    <div class="text">We produce the best modified pharma and food industry machineries to cope up with the modernization. For long-term business prospects, we offer our customers with highly innovative solutions.</div>
                                    
                                    
                                
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="col-lg-5 col-sm-6 col-xs-12 column">
                                <div class="sec-title-three">
                                	<h2>Quick Links</h2>
                                </div>
                                <div class="footer-widget links-widget">
                                    <ul>
                                        <li><a href="#">Home</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="#">Products</a></li>
                                        <li><a href="#">Contact</a></li>
                                    </ul>
        
                                </div>
                            </div>
                    	</div>
                    </div>
                    <!--Two 4th column End-->
                    
                    <!--Two 4th column-->
                    <div class="col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">
                    		<!--Footer Column-->
                        	<div class="col-lg-6 col-sm-6 col-xs-12 column">
                            <div class="sec-title-three">
                                	<h2>Products</h2>
                                </div>
                                <div class="footer-widget links-widget">
                                    <ul>
                                        <li><a href="#">Pharma Machineries</a></li>
                                        <li><a href="#">Food Industry Machineries</a></li>
                                        <li><a href="#">Metal Detectors</a></li>
                                        <li><a href="#">All types Of Conveyor</a></li>
                                        
                                    </ul>
        
                                </div>
                              
                            </div>
                           
                            <!--Footer Column-->
                    		<div class="col-md-6 col-sm-6 col-xs-12 column">
                    			<div class="footer-widget gallery-widget">
                                    <div class="sec-title-three">
                                    	<h2>Contact Us</h2>
                                    </div>
                                    <div class="clearfix">
                                        <ul class="contact-info">
                                    	<li><span class="icon flaticon-pin"></span> Hindustan Technology System
Gala no 1 Agi kampawant Wakipada, Naigaon E Rd, Vasai-Virar, Maharashtra 401208</li>
                                        <li><span class="icon flaticon-technology"></span> +91-7410-176680
</li>
                                    </ul>
                                    </div>
                                </div>
                    		</div>
                    
                    	</div>
                    </div><!--Two 4th column End-->
                    
                </div>
                
            </div>
        </div>
        
        <!--Footer Bottom-->
    	<div class="footer-bottom">
            <div class="auto-container">
            	<div class="row clearfix">
                    <!--Copyright-->
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="copyright">Copyrights &copy; 2016 Brighton. All Rights Reserved.</div>
                    </div>
                    
                    
                
                </div>
            </div>
        </div>
        
    </footer>