<!--Main Footer-->
<footer class="main-footer">
    	
        <!--Footer Upper-->        
        <div class="footer-upper">
            <div class="auto-container">
                <div class="row clearfix">
                	
                    <!--Two 4th column-->
                    <div class="col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">
                            <div class="col-lg-7 col-sm-6 col-xs-12 column">
                                <div class="footer-widget logo-widget">
                                    <div class="logo"><a href="index.html"><img src="images/finalogo.png" class="img-responsive" alt=""></a></div>
                                    <div class="text">The year is and launches the last of that americas deep space probes and we will our our way make all come true.</div>
                                    
                                    <ul class="contact-info">
                                    	<li><span class="icon flaticon-pin"></span> 3A07, Serif St, Orleans, USA-170A</li>
                                        <li><span class="icon flaticon-technology"></span> +1 - 000 - 8990 - 1560</li>
                                        <li><span class="icon flaticon-mail-2"></span> support@domain.com</li>
                                    </ul>
                                
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="col-lg-5 col-sm-6 col-xs-12 column">
                                <div class="sec-title-three">
                                	<h2>Quick Links</h2>
                                </div>
                                <div class="footer-widget links-widget">
                                    <ul>
                                        <li><a href="#">Home</a></li>
                                        <li><a href="#">About Us</a></li>
                                        <li><a href="#">Products</a></li>
                                        <li><a href="#">Contact</a></li>
                                    </ul>
        
                                </div>
                            </div>
                    	</div>
                    </div>
                    <!--Two 4th column End-->
                    
                    <!--Two 4th column-->
                    <div class="col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">
                    		<!--Footer Column-->
                        	<div class="col-lg-6 col-sm-6 col-xs-12 column">
                            <div class="sec-title-three">
                                	<h2>Products</h2>
                                </div>
                                <div class="footer-widget links-widget">
                                    <ul>
                                        <li><a href="#">Pharma Machineries</a></li>
                                        <li><a href="#">Food Industry Machineries</a></li>
                                        <li><a href="#">Metal Detectors</a></li>
                                        <li><a href="#">All types Of Conveyor</a></li>
                                        
                                    </ul>
        
                                </div>
                              
                            </div>
                           
                            <!--Footer Column-->
                    		<div class="col-md-6 col-sm-6 col-xs-12 column">
                    			<div class="footer-widget gallery-widget">
                                    <div class="sec-title-three">
                                    	<h2>Contact Us</h2>
                                    </div>
                                    <div class="clearfix">
                                        <h3>HindustanTechnology</h3>
                                    </div>
                                </div>
                    		</div>
                    
                    	</div>
                    </div><!--Two 4th column End-->
                    
                </div>
                
            </div>
        </div>
        
        <!--Footer Bottom-->
    	<div class="footer-bottom">
            <div class="auto-container">
            	<div class="row clearfix">
                    <!--Copyright-->
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="copyright">Copyrights &copy; 2016 Brighton. All Rights Reserved.</div>
                    </div>
                    
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="footer-bottom-social">
                            <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                            <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            <li><a href="#"><span class="fa fa-flickr"></span></a></li>
                        </ul>
                    </div>
                
                </div>
            </div>
        </div>
        
    </footer>