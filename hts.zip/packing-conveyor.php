<!DOCTYPE html>
<html>

<!-- Mirrored from world5.commonsupport.com/html2/brighton/services-details.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Jun 2020 16:00:25 GMT -->
<head>
<?php include 'commonlinks.php'?>
<?php 

// var_dump($productData);
?>
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"><div class="loader"><div class="cssload-container"><div class="cssload-speeding-wheel"></div></div></div></div>
 	
    <!-- Main Header-->
    <?php include 'header.php'?>
    <!--End Main Header -->
    
    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/featured-2-bg.jpg);">
        <div class="auto-container">
            <h1>Packing Conveyor</h1>
        </div>
        
        <!--page-info-->
        <div class="page-info">
        	<div class="auto-container">
            	<div class="row clearfix">
            
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="bread-crumb clearfix">
                            <li><a href="index.php">Home</a></li>
                            <li class="active">Packing Conveyor</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
    </section>
    
    <!--Sidebar Page-->
    <div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">

                <!--Content Side-->
                <div class="content-side col-lg-9 col-md-8 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/pc1.jpg" alt=""></figure>
						<div class="sec-title-one"><h2>Packing Conveyor</h2></div>

                        <div class="text-block">
                            <p>The packing conveyor is configured with the help of high quality stainless steel in
accordance with the quality standards laid by the industry. It is available in varied lengths and is sophisticatedly
designed in order to meet the requirement of the customers. characteristic Features The structure of the packing
conveyor belts &amp; is made of the SS 304, &amp; square pipe with the matt finish.
The length of packing conveyor can be made as per the need of belt. There is a direct gear
drive available in the PVC packing conveyor belt.</p>
                        </div>

                        <div class="row clearfix">
                        	
                            
                            <div class="col-md-12 col-sm-12 col-xs-12">
                            	<div class="sec-title-one"><h2>Features</h2></div>
                                <!-- <div class="text">The way we all became the Brady come and listen to a story about a man barely kept his family never heard to the word able this time there is no stopng us the Love Boat soon will be making another run the Love Boat in a promises onething for a eryone be from me and the card attached.</div> -->
                                
                                <ul class="list-style-one">
                                    <li><span class="fa fa-check-square-o"></span> <strong> Height of Conveyor : </strong> 860 mm to 910 mm, endless 2 ply sandwich, 2mm thickness PVC, endless
                                     2 ply sandwich, 2mm thickness PVC, endless 2 ply sandwich, 2mm thickness. </li>
                                    <li><span class="fa fa-check-square-o"></span> <strong>Power characteristic : </strong> 0.5 HP/220v/50 Hz 0.5 HP/220v/50Hz</li>
                                </ul>
                                

                            
                        </div>
						
                     
                       
                        </div>
                        <div class="row clearfix">
                        	
                            
                            <div class="col-md-12 col-sm-12 col-xs-12">
                            	
                        </div>
						
                     
                       
                        </div>
                        
                    </section>

				</div>
                <!--Content Side-->

				<!--Sidebar-->
                <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12">
                    <aside class="sidebar about-sidebar">

                        <?php include 'pharma-product-list.php'?>

                        <!-- Tabbed Links -->
                        <div class="sidebar-widget download-links">
                            <div class="sec-title-seven"><h2>Download Brochures</h2></div>
                            <ul class="files">
                            	<li><a href="#"><span class="fa fa-file-pdf-o"></span> Download PDF</a></li>
                            </ul>

                        </div>

						<!--quote-widget-->
						<?php include 'query-box.php'?>

                    </aside>


                </div>
                <!--Sidebar-->


            </div>
        </div>
    </div>
    
    <!--Main Footer-->
    <?php include 'footer.php'?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/script.js"></script>
<?php include 'quote.php'?>
</body>

<!-- Mirrored from world5.commonsupport.com/html2/brighton/services-details.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Jun 2020 16:00:48 GMT -->
</html>
